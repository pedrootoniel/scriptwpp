# SendScriptWhatsApp

Código para enviar o Script inteiro de Shrek ou Bee Movie para seus amigos ou grupos do WhatsApp

## Utilização

Abra [shrekSendScript.js](https://github.com/Matt-Fontes/SendScriptWhatsApp/blob/main/shrekSendScript.js)
Ou
Abra [beeMovieSendScript.js](https://github.com/Matt-Fontes/SendScriptWhatsApp/blob/main/beeMovieSendScript.js)

Copie todo o conteúdo (clique em raw -> ctrl+a -> ctrl+c)

No WhatsApp Web abra o console do Browser

Cole o código no console e aperte Enter

Pronto
